This folder contains two versions of the HL7 models produced by the HL7 tooling.  
The business version is collapsed (i.e., denormalized) and includes only those 'business' data elements that might be of interest to end-users.  
The verbose version is the full representation of the source model.

The source .html version can be converted to MSWord by a simple copy & paste operation.  An MSWord template is provided.
